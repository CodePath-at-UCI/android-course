package com.codepath.android.booksearch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class OpenActivity extends AppCompatActivity {
    //Create a button variable (you can call it anything you want

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);
        //Fetch the button using findViewById and store it in the variable you created above

        //setOnClickListener to the button

        //Create an intent object to change the screen from this class to BookListActivity class
        // (Follow the lab2 video on the CodePath YouTube channel (You can find the link on the GitHub repository as well)

    }
}
