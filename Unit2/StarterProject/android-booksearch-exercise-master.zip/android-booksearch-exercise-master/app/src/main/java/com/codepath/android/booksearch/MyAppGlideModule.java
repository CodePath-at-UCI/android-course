package com.codepath.android.booksearch;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

// Needed for Glide v4 to use to load placeholder images
// See https://bumptech.github.io/glide/doc/migrating.html
@GlideModule
public final class MyAppGlideModule extends AppGlideModule {}